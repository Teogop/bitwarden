DROP TABLE users;

DROP TABLE devices;

DROP TABLE ciphers;

DROP TABLE attachments;

DROP TABLE folders;