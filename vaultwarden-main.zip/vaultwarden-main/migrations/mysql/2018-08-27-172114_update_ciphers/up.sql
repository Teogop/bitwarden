ALTER TABLE ciphers
    ADD COLUMN
    password_history TEXT;