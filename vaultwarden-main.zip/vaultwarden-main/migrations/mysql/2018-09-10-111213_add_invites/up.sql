CREATE TABLE invitations (
    email   VARCHAR(255) NOT NULL PRIMARY KEY
);
