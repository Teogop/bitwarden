ALTER TABLE attachments
    ADD COLUMN
    key TEXT;