CREATE TABLE invitations (
    email   TEXT NOT NULL PRIMARY KEY
);